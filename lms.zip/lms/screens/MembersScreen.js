import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Dimensions,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const { width } = Dimensions.get("window");

export default function MembersScreen({ navigation }) {
  const [members, setMembers] = useState([]);
  const [newMember, setNewMember] = useState({
    firstName: "",
    lastName: "",
    semester: "",
    course: "",
    degree: "",
    email: "",
    phone: "",
    membershipType: "",
    from: "",
    to: "",
    reason: "",
  });

  const addMember = () => {
    const values = Object.values(newMember);
    if (values.some((v) => !v)) {
      Alert.alert("Error", "Please fill all fields!");
      return;
    }

    setMembers((prev) => [
      ...prev,
      { id: prev.length + 1, ...newMember },
    ]);

    setNewMember({
      firstName: "",
      lastName: "",
      semester: "",
      course: "",
      degree: "",
      email: "",
      phone: "",
      membershipType: "",
      from: "",
      to: "",
      reason: "",
    });

    Alert.alert("Success", "Member added successfully!");
  };

  return (
    <ScrollView style={styles.container}>
      {/* White Header Bar */}
      <View style={styles.headerBar}>
        <TouchableOpacity
          onPress={() => navigation.toggleDrawer()}
          style={styles.drawerIcon}
        >
          <Ionicons name="menu" size={28} color="#008080" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>📋 Manage Members</Text>
      </View>

      {/* Form Section */}
      <View style={styles.formContainer}>
        {[
          { label: "First Name", key: "firstName" },
          { label: "Last Name", key: "lastName" },
          { label: "Semester", key: "semester" },
          { label: "Course", key: "course" },
          { label: "Degree", key: "degree" },
          { label: "Email", key: "email" },
          { label: "Phone", key: "phone" },
          { label: "Membership Type", key: "membershipType" },
          { label: "From", key: "from" },
          { label: "To", key: "to" },
        ].map((field) => (
          <View key={field.key} style={styles.inputGroup}>
            <Text style={styles.label}>{field.label}</Text>
            <TextInput
              style={styles.input}
              value={newMember[field.key]}
              onChangeText={(text) =>
                setNewMember({ ...newMember, [field.key]: text })
              }
            />
          </View>
        ))}

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Reason / Objective</Text>
          <TextInput
            style={[styles.input, { height: 60 }]}
            multiline
            value={newMember.reason}
            onChangeText={(text) =>
              setNewMember({ ...newMember, reason: text })
            }
          />
        </View>

        <TouchableOpacity style={styles.addButton} onPress={addMember}>
          <Text style={styles.addButtonText}>➕ Add Member</Text>
        </TouchableOpacity>
      </View>

      {/* Members List */}
      {members.length > 0 && (
        <View style={styles.listContainer}>
          <Text style={styles.listTitle}>Members List</Text>
          <FlatList
            data={members}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View style={styles.memberCard}>
                <Text style={[styles.memberField, { color: "#004D4D" }]}>
                  Name:{" "}
                  <Text style={styles.memberValue}>
                    {item.firstName} {item.lastName}
                  </Text>
                </Text>
                <Text style={[styles.memberField, { color: "#FF7A00" }]}>
                  Course: <Text style={styles.memberValue}>{item.course}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#004D4D" }]}>
                  Semester: <Text style={styles.memberValue}>{item.semester}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#FF7A00" }]}>
                  Degree: <Text style={styles.memberValue}>{item.degree}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#004D4D" }]}>
                  Email: <Text style={styles.memberValue}>{item.email}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#FF7A00" }]}>
                  Phone: <Text style={styles.memberValue}>{item.phone}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#004D4D" }]}>
                  Membership Type:{" "}
                  <Text style={styles.memberValue}>{item.membershipType}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#FF7A00" }]}>
                  From: <Text style={styles.memberValue}>{item.from}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#004D4D" }]}>
                  To: <Text style={styles.memberValue}>{item.to}</Text>
                </Text>
                <Text style={[styles.memberField, { color: "#FF7A00" }]}>
                  Reason: <Text style={styles.memberValue}>{item.reason}</Text>
                </Text>
              </View>
            )}
          />
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#E6F4F1",
    paddingHorizontal: 15,
    paddingBottom: 20,
  },

  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderRadius: 12,
    elevation: 4,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    marginTop: 50,
    marginBottom: 20,
  },
  drawerIcon: { width: 40, alignItems: "flex-start" },
  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#004D4D", // updated darker teal
    marginLeft: 10,
  },

  formContainer: {
    backgroundColor: "#F9F9F9",
    borderRadius: 18,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
    marginBottom: 25,
  },
  inputGroup: { marginBottom: 15 },
  label: {
    fontWeight: "600",
    fontSize: 14,
    color: "#00575B", // updated darker teal for labels
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 15,
    fontSize: 14,
    backgroundColor: "#fff",
  },

  addButton: {
    backgroundColor: "#FF7A00",
    paddingVertical: 14,
    borderRadius: 30,
    marginTop: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 4,
  },
  addButtonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
  },

  listContainer: { marginBottom: 30 },
  listTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#004D4D", // updated darker teal
    marginBottom: 10,
  },

  memberCard: {
    backgroundColor: "#F9F9F9",
    borderRadius: 15,
    padding: 15,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  memberField: {
    fontWeight: "600",
    marginBottom: 4,
  },
  memberValue: {
    fontWeight: "400",
    color: "#222", // darker value text
  },
});

import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Modal,
  Alert,
  Dimensions,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const { width } = Dimensions.get("window");

export default function BooksScreen({ navigation }) {
  const [books, setBooks] = useState([
    { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", category: "Classic", quantity: 5 },
  ]);

  const [modalVisible, setModalVisible] = useState(false);
  const [newBook, setNewBook] = useState({ title: "", author: "", category: "", quantity: "" });

  const addBook = () => {
    const { title, author, category, quantity } = newBook;
    if (!title || !author || !category || !quantity) {
      Alert.alert("Error", "Please fill all fields!");
      return;
    }

    setBooks((prev) => [
      ...prev,
      { id: prev.length + 1, title, author, category, quantity: parseInt(quantity) },
    ]);

    setNewBook({ title: "", author: "", category: "", quantity: "" });
    setModalVisible(false);
  };

  const deleteBook = (id) => {
    setBooks((prev) => prev.filter((book) => book.id !== id));
  };

  const renderBookCard = ({ item }) => (
    <View style={styles.bookCard}>
      <View style={styles.cardHeader}>
        <Text style={[styles.heading, { backgroundColor: "#008080" }]}>ID: {item.id}</Text>
        <TouchableOpacity onPress={() => deleteBook(item.id)}>
          <Ionicons name="trash-outline" size={24} color="#FF4D00" />
        </TouchableOpacity>
      </View>
      <Text style={[styles.heading, { backgroundColor: "#FF7A00" }]}>Title</Text>
      <Text style={styles.cardText}>{item.title}</Text>

      <Text style={[styles.heading, { backgroundColor: "#008080" }]}>Author</Text>
      <Text style={styles.cardText}>{item.author}</Text>

      <Text style={[styles.heading, { backgroundColor: "#FF7A00" }]}>Category</Text>
      <Text style={styles.cardText}>{item.category}</Text>

      <Text style={[styles.heading, { backgroundColor: "#008080" }]}>Quantity</Text>
      <Text style={styles.cardText}>{item.quantity}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.toggleDrawer()} style={styles.drawerIcon}>
          <Ionicons name="menu" size={28} color="#008080" />
        </TouchableOpacity>

        <Text style={styles.headerTitle}>📚 Manage Books</Text>

        <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
          <Ionicons name="add-circle" size={28} color="#FF7A00" />
        </TouchableOpacity>
      </View>

      {/* Books List */}
      <FlatList
        data={books}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderBookCard}
        contentContainerStyle={{ paddingBottom: 20 }}
      />

      {/* Modal */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add New Book</Text>
            <TextInput
              placeholder="Book Title"
              style={styles.input}
              value={newBook.title}
              onChangeText={(text) => setNewBook({ ...newBook, title: text })}
            />
            <TextInput
              placeholder="Author Name"
              style={styles.input}
              value={newBook.author}
              onChangeText={(text) => setNewBook({ ...newBook, author: text })}
            />
            <TextInput
              placeholder="Category"
              style={styles.input}
              value={newBook.category}
              onChangeText={(text) => setNewBook({ ...newBook, category: text })}
            />
            <TextInput
              placeholder="Quantity"
              style={styles.input}
              keyboardType="numeric"
              value={newBook.quantity}
              onChangeText={(text) => setNewBook({ ...newBook, quantity: text })}
            />
            <TouchableOpacity style={styles.modalButton} onPress={addBook}>
              <Text style={styles.modalButtonText}>Add Book</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.modalCancel} onPress={() => setModalVisible(false)}>
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 15, backgroundColor: "#E6F4F1" },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 20,
    backgroundColor: "#fff",
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderRadius: 18,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  drawerIcon: { width: 40, alignItems: "flex-start" },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#008080", flex: 1, textAlign: "center" },
  addButton: { width: 40, alignItems: "flex-end" },

  bookCard: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 15,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 },
  heading: {
    color: "#fff",
    fontWeight: "700",
    paddingVertical: 3,
    paddingHorizontal: 6,
    borderRadius: 6,
    marginTop: 5,
    fontSize: 14,
  },
  cardText: { fontSize: 14, color: "#333", marginBottom: 3 },

  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center" },
  modalContent: { width: width * 0.9, backgroundColor: "#fff", borderRadius: 12, padding: 20 },
  modalTitle: { fontSize: 20, fontWeight: "700", marginBottom: 10, color: "#008080" },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 8, padding: 10, marginVertical: 5 },
  modalButton: { backgroundColor: "#FF7A00", padding: 12, borderRadius: 8, marginTop: 10, alignItems: "center" },
  modalButtonText: { color: "#fff", fontWeight: "600" },
  modalCancel: { marginTop: 10, alignItems: "center" },
  modalCancelText: { color: "#008080", fontWeight: "600" },
});

import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { PieChart } from "react-native-chart-kit";
import { LinearGradient } from "expo-linear-gradient";
import { Picker } from "@react-native-picker/picker";

const { width } = Dimensions.get("window");

export default function DashboardScreen({ navigation }) {
  const [selectedFilter, setSelectedFilter] = useState("current");
  const [showChart, setShowChart] = useState(false);

  const stats = {
    current: {
      totalBooks: 1200,
      issuedBooks: 320,
      returnedBooks: 280,
      memberships: 450,
      visitors: 750,
    },
    monthly: {
      totalBooks: 200,
      issuedBooks: 90,
      returnedBooks: 70,
      memberships: 40,
      visitors: 150,
    },
    yearly: {
      totalBooks: 1200,
      issuedBooks: 1100,
      returnedBooks: 1050,
      memberships: 500,
      visitors: 900,
    },
  };

  const current = stats[selectedFilter];

  const pieData = [
    { name: "Total Books", population: current.totalBooks, color: "#00a497", legendFontColor: "#333", legendFontSize: 13 },
    { name: "Issued", population: current.issuedBooks, color: "#ff7a00", legendFontColor: "#333", legendFontSize: 13 },
    { name: "Returned", population: current.returnedBooks, color: "#2196f3", legendFontColor: "#333", legendFontSize: 13 },
    { name: "Memberships", population: current.memberships, color: "#f44336", legendFontColor: "#333", legendFontSize: 13 },
    { name: "Visitors", population: current.visitors, color: "#ffa500", legendFontColor: "#333", legendFontSize: 13 },
  ];

  return (
    <LinearGradient colors={["#E6F4F1", "#D0F0EC"]} style={styles.container}>
      {/* Header */}
      <View style={styles.headerBar}>
        <TouchableOpacity onPress={() => navigation.toggleDrawer()} style={styles.menuButton}>
          <Ionicons name="menu" size={28} color="#008080" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Dashboard</Text>
      </View>

      {/* Filter Dropdown */}
      <View style={styles.filterContainer}>
        <Text style={styles.filterLabel}>Filter:</Text>
        <View style={styles.pickerWrapper}>
          <Picker
            selectedValue={selectedFilter}
            onValueChange={(itemValue) => setSelectedFilter(itemValue)}
            style={styles.picker}
            dropdownIconColor="#008080"
          >
            <Picker.Item label="Current" value="current" />
            <Picker.Item label="Monthly" value="monthly" />
            <Picker.Item label="Yearly" value="yearly" />
          </Picker>
        </View>
      </View>

      {/* Stats Cards */}
      <View style={styles.cardsContainer}>
        <View style={[styles.card, { borderLeftColor: "#00a497" }]}>
          <Text style={styles.cardTitle}>Total Books</Text>
          <Text style={styles.cardValue}>{current.totalBooks}</Text>
        </View>
        <View style={[styles.card, { borderLeftColor: "#ff7a00" }]}>
          <Text style={styles.cardTitle}>Issued Books</Text>
          <Text style={styles.cardValue}>{current.issuedBooks}</Text>
        </View>
        <View style={[styles.card, { borderLeftColor: "#2196f3" }]}>
          <Text style={styles.cardTitle}>Returned Books</Text>
          <Text style={styles.cardValue}>{current.returnedBooks}</Text>
        </View>
        <View style={[styles.card, { borderLeftColor: "#f44336" }]}>
          <Text style={styles.cardTitle}>Memberships</Text>
          <Text style={styles.cardValue}>{current.memberships}</Text>
        </View>
        <View style={[styles.card, { borderLeftColor: "#ffa500" }]}>
          <Text style={styles.cardTitle}>Visitors</Text>
          <Text style={styles.cardValue}>{current.visitors}</Text>
        </View>
      </View>

      {/* Chart Section */}
      <TouchableOpacity
        style={styles.chartBox}
        onPress={() => setShowChart(!showChart)}
      >
        <Text style={styles.chartTitle}>📊 Statistics Overview</Text>
        {!showChart ? (
          <Text style={styles.chartPlaceholder}>
            Tap to view Pie Chart visualization
          </Text>
        ) : (
          <PieChart
            data={pieData}
            width={width * 0.9}
            height={220}
            chartConfig={{
              backgroundColor: "#fff",
              backgroundGradientFrom: "#E6F4F1",
              backgroundGradientTo: "#fff",
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(0, 128, 128, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        )}
      </TouchableOpacity>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 15, paddingBottom: 30 },

  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginTop: 50,
    marginBottom: 20,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 6,
  },
  menuButton: { marginRight: 15 },
  headerTitle: { fontSize: 22, fontWeight: "700", color: "#008080" },

  filterContainer: { flexDirection: "row", alignItems: "center", marginBottom: 25 },
  filterLabel: { fontSize: 16, fontWeight: "600", color: "#008080", marginRight: 10 },
  pickerWrapper: {
    flex: 1,
    borderWidth: 2,
    borderColor: "#008080",
    borderRadius: 12,
    overflow: "hidden",
    backgroundColor: "#fff",
    height: 45,
    justifyContent: "center",
  },
  picker: { height: 45, width: "100%", color: "#008080" },

  cardsContainer: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  card: {
    width: "48%",
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 18,
    marginBottom: 15,
    borderLeftWidth: 6,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 5,
  },
  cardTitle: { fontSize: width * 0.04, color: "#333", fontWeight: "600", marginBottom: 6 },
  cardValue: { fontSize: width * 0.07, fontWeight: "800", color: "#008080" },

  chartBox: {
    marginVertical: 30,
    backgroundColor: "#fff",
    borderRadius: 18,
    paddingVertical: 30,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
  },
  chartTitle: { fontSize: 20, fontWeight: "700", color: "#008080", marginBottom: 8 },
  chartPlaceholder: { color: "#888", fontSize: 14 },
});
